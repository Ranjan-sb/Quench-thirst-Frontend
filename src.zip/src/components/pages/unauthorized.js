export default function Unauthorized() {
    return (
        <h2>You are not authorized to access this page</h2>
    )
}