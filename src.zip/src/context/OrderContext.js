import { createContext } from "react";

export const OrderContext=createContext()