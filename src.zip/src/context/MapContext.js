import { createContext } from "react";

export const MapLocationContext=createContext()

